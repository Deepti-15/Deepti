 function PrintElem(elem,pname)
{
    var mywindow = window.open('', 'PRINT', 'height=400,width=600');
    mywindow.document.write(document.getElementById(elem).innerHTML);
    mywindow.document.close(); // necessary for IE >= 10
    mywindow.focus(); // necessary for IE >= 10*/
    mywindow.print();
	location.href=pname;
	mywindow.close();
}
// JavaScript Document