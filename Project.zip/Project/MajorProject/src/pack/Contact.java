
package pack;
//import java.util.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class Contact extends HttpServlet {
  

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
      response.setContentType("text/html;charset=UTF-8");
      PrintWriter out = response.getWriter();
      //ArrayList a=new ArrayList();
	
      String name = request.getParameter("name");
      String email = request.getParameter("email");
      String phone = request.getParameter("phn");
      String message = request.getParameter("msg");
      
      try {
      
          // loading drivers for mysql
          Class.forName("oracle.jdbc.driver.OracleDriver");
          
          //creating connection with the database 
          Connection con = DriverManager.getConnection
                      ("jdbc:oracle:thin:@localhost:1521:xe","system","scott");

          PreparedStatement ps = con.prepareStatement
                      ("insert into contact values(?,?,?,?)");

          ps.setString(1, name);
          ps.setString(2, email);
          ps.setString(3, phone);
          ps.setString(4, message);
          int i = ps.executeUpdate();
          
          if(i > 0) {
          out.println("done");
          }
      
      }
      catch(Exception se) {
          se.printStackTrace();
      }
	
  }
}