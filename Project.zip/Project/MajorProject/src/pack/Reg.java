
package pack;
//import java.util.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class Reg extends HttpServlet {
  

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
      response.setContentType("text/html;charset=UTF-8");
      PrintWriter out = response.getWriter();
      //ArrayList a=new ArrayList();
	
      String a = request.getParameter("email");
      String b = request.getParameter("name");
      String c = request.getParameter("phn");
      String d = request.getParameter("addr");
      
      try {
      
          // loading drivers for mysql
          Class.forName("oracle.jdbc.driver.OracleDriver");
          
          //creating connection with the database 
          Connection con = DriverManager.getConnection
                      ("jdbc:oracle:thin:@localhost:1521:xe","system","scott");

          PreparedStatement ps = con.prepareStatement
                      ("insert into reg values(?,?,?,?)");

          ps.setString(1, a);
          ps.setString(2, b);
          ps.setString(3, c);
          ps.setString(4, d);
          int i = ps.executeUpdate();
          
          if(i > 0) {
        	 out.println("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\r\n" + 
        	 		"<html xmlns=\"http://www.w3.org/1999/xhtml\">\r\n" + 
        	 		"<head>\r\n" + 
        	 		"<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\r\n" + 
        	 		"<title>ABHINAVA MANTRALAYA</title>\r\n" + 
        	 		"<link href=\"css/reg.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n" + 
        	 		"</head>\r\n" + 
        	 		" \r\n" + 
        	 		"<body>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		" <br><br><br><br><br>\r\n" + 
        	 		" \r\n" + 
        	 		"<div class=\"login-card\">\r\n" + 
        	 		" \r\n" + 
        	 		"<div class=\"log_head\">\r\n" + 
        	 		" \r\n" + 
        	 		"<h1>Enter OTP</h1>\r\n" + 
        	 		" \r\n" + 
        	 		"</div>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"<div class=\"log_body\">\r\n" + 
        	 		" \r\n" + 
        	 		"<form action=\"#\" method=\"post\">\r\n" + 
        	 		" \r\n" + 
        	 		"<table width=\"200\" border=\"0\" align=\"center\">\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"<tr>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"<td><input  type=\"number\" name=\"otp\" class=\"log_user\" required></td>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"</tr>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"\r\n" + 
        	 		" <tr>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"<td>&nbsp;</td>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"</tr>\r\n" + 
        	 		"<tr>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"<td>&nbsp;</td>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"</tr>\r\n" + 
        	 		"<tr>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"<td>&nbsp;</td>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"</tr><br>\r\n" + 
        	 		"\r\n" + 
        	 		"<tr>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"<td><input type=\"submit\" name=\"register\" class=\"login-submit\" value=\"Register\"></td>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"</tr>\r\n" + 
        	 		" \r\n" + 
        	 		"<tr>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"<td>&nbsp;</td>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"</tr>\r\n" + 
        	 		" \r\n" + 
        	 		"<tr>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"<td><input type=\"submit\" name=\"resend\" class=\"login-submit\" value=\"Resend OTP\"></td>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"</tr>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"</table>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"</form>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"</div>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"</div>\r\n" + 
        	 		" \r\n" + 
        	 		" \r\n" + 
        	 		"</body>\r\n" + 
        	 		"</html>");
            
          }
      
      }
      catch(Exception se) {
          se.printStackTrace();
      }
	
  }
}