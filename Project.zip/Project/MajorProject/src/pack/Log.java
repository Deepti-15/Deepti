package pack;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;



public class Log extends HttpServlet {
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        String name1 = request.getParameter("name");
        String pass1 = request.getParameter("pass");
        
        if(Validate.checkUser(name1, pass1))
        {
        	   
            RequestDispatcher rs = request.getRequestDispatcher("otp.html");
            rs.forward(request, response);
        }
        else
        {
           out.println("Username or Password incorrect");
           RequestDispatcher rs = request.getRequestDispatcher("login.html");
           rs.include(request, response);
        }
    }  
}